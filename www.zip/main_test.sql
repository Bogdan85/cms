-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 26, 2014 at 03:02 PM
-- Server version: 5.1.40
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `main_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `path` text NOT NULL,
  `title` text NOT NULL,
  `keywords` text NOT NULL,
  `description` text NOT NULL,
  `h1` text NOT NULL,
  `text` text NOT NULL,
  `template` int(3) NOT NULL,
  `for_bread` text NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `parent_id` tinyint(1) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL,
  `level` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `path`, `title`, `keywords`, `description`, `h1`, `text`, `template`, `for_bread`, `in_menu`, `parent_id`, `time`, `active`, `level`) VALUES
(1, 'Главная', '/', 'Заголовок главной страницы', 'Кивордс главной страницы', 'Дескрипшн главной страницы', 'аш1 для главной1', '<p>Это текст</p>', 1, 'Для крошек текст', 0, 0, '2014-09-18 17:43:18', 0, 0),
(2, 'Новости', 'news', 'Новости1', 'Новости', 'Новости', 'Новости2', '<p>Новости</p>', 2, 'Новости3', 1, 0, '2014-09-14 11:01:40', 0, 0),
(3, 'Новина1', 'firstnew', 'Новина1', 'Новина1', 'Новина1', 'Новина1', '<p>Новина1</p>', 2, 'Новина1', 0, 2, '2014-09-15 17:47:31', 0, 1),
(4, 'Статьи', 'articles', 'Статьи', 'Статьи', 'Статьи', 'Статьи', '<p>Статьи</p>', 1, 'Статьи', 1, 0, '2014-09-12 17:29:28', 0, 0),
(5, '12313', '1231231', '123123', '12313', '123213', '123123', '<p>123123123</p>', 1, '123123', 0, 3, '2014-09-15 17:17:28', 0, 2),
(7, 'news2', 'news2', 'news2', 'news2', 'news2', 'news2', '<p>news2</p>', 1, 'news2', 0, 2, '2014-09-15 17:39:11', 0, 1),
(9, 'news3', 'news3', 'news3', 'news3', 'news3', 'news3', '<p>news3</p>', 1, 'news3', 0, 7, '2014-09-15 17:43:32', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`id`, `name`) VALUES
(1, 'Основной'),
(2, 'Второй шаблон');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `pass`) VALUES
(1, 'test', 'af4c33da45b02804099fe4a7f4a0ed20');
