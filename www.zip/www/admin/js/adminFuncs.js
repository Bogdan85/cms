		function change_but(pid, val){		
			// функция с аяксом - изменение кнопки активности раздела
			var toAjax = pid;
			var toAjax2 = val;
			
				$.ajax({
					url:"/admin/application/core/handlerChange.php",
					type:"POST",
					data: {id: toAjax, value: toAjax2},
					error:function(){
						alert('Error');
					},
					success:function(text){

						pid = new String(pid);
						var ext = '#toChange' + pid;
						val = (val == 1) ? 0 : 1;

						if(val == 1){
							$(ext).html('<a href="#" onclick="change_but('+pid+', '+val+');"><img alt="Активность" title="Активность" src="/admin/images/active.png" align="absmiddle"></a>');						
						}else if(val == 0){		
							$(ext).html('<a href="#" onclick="change_but('+pid+', '+val+');"><img alt="Активность" title="Активность" src="/admin/images/notActive.png" align="absmiddle"></a>');						
						}
						
						  $( "#hint" ).fadeIn( "slow", function() {
							// Animation complete
						  });

						  $( "#hint" ).delay(1000).fadeOut( "slow", function() {
						    // Animation complete.
						  });
					}       
				});		
		}
		
		function setCookRu() {
			document.cookie="language=ru";
			location.reload();
		}
		
		function setCookEn() {
			document.cookie="language=en";
			location.reload();
		}
		
		function del_cat(cid){	
		
			if (confirm("Точно удаляем?") == true) {
				//return true;
			} else {
				return false;
			}
			
			// функция с аяксом - удаление раздела
			var toAjax = cid;
				$.ajax({
					url:"/admin/application/core/handlerDel.php",
					type:"POST",
					data: {del: toAjax},
					error:function(){
						alert('Error');
					},
					success:function(text){
						location.reload();					
					}       
				});		
		}