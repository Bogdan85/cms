<?php
ini_set('display_errors', 1);
include_once 'application/bootstrap.php';