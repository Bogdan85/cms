<?php

class Controller_Edit extends Controller
{

	function __construct()
	{
		$this->model = new Model_Edit();
		$this->view = new View();
	}
	
	function action_index()
	{
		if($_SESSION['login'] == 'opened') {
			$data = $this->model->get_data();		
			$this->view->generate('edit_view.php', $data);
		}else{
			$data = '';
			$this->view->generate('login_view.php', $data);
		}
	}
}