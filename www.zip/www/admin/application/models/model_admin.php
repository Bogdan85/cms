<?php

class Model_Admin extends Model
{

	//рекурсивная функция выборки подкатегорий
	public function recursiveSearch($id, $pos, $ooo){

		$id = intval($id);
		global $DB;
		global $res;		

		$cats2 = $DB->prepare("SELECT * FROM categories 
							   WHERE parent_id = $id 
							   ORDER BY id");
		$cats2->execute();

		while ($row2 = $cats2->fetch(PDO::FETCH_ASSOC)) {
		
			if($ooo !== 'no'){
			
				$res[$pos]['subs'][$ooo]['subs'][] = $row2;
				
			}else{

				$res[$pos]['subs'][] = $row2;
				
			}

		}
		
		if($row2['parent_id'] != NULL){

			$last = intval($row2['parent_id']);	
			recursiveSearch($last);

		}else{
		}
			
		return $resSubs;

	}

	//функция выборки главных категорий
	public function get_data()
	{		
		global $DB;	
		global $res;

		$res = array();

		$cats = $DB->prepare("SELECT * FROM categories 
							  WHERE parent_id = 0 
							  AND id <> 1 
							  ORDER BY id");
		$cats->execute();

		while ($row = $cats->fetch(PDO::FETCH_ASSOC)) {
			$res[] = $row;
		}

		// второй уровень
		$count1 = count($res);
		for($i=0;$i<$count1;++$i){

			if($res[$i]["id"] != NULL) {

				$this->recursiveSearch($res[$i]["id"], $i, 'no');

			}

		}	

		//третий уровень
		$count2 = count($res);
		$count3 = count($res[$ii]["subs"]);
		
		for($ii=0;$ii<$count2;++$ii){

			for($aa=0;$aa<$count3;++$aa){

				if($res[$ii]["subs"][$aa]["id"] != NULL) {

					$this->recursiveSearch($res[$ii]["subs"][$aa]["id"], $ii, $aa);

				}

			}
	
		}

		//добавим главную в начало, так как у нее нет подстраниц
		$cats = $DB->prepare("SELECT * FROM categories 
							  WHERE id = 1");
		$cats->execute();

		while ($row = $cats->fetch(PDO::FETCH_ASSOC)) {

			array_unshift($res, $row);

		}

		return $res;
	}
}