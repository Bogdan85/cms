<?php
class Model_Edit extends Model
{

	//выбираем страницу по айди
	public function get_data()
	{		
		global $DB;	

		$res = array();
		$fromGet = $_GET['id'];

		// выбираем категорию
		$cats = $DB->prepare("SELECT * 
							  FROM categories 
							  WHERE id = $fromGet");
		$cats->execute();

		while ($row = $cats->fetch(PDO::FETCH_ASSOC)) {
			$res["main"] = $row;
		}

		// если не найдено
		if($res["main"] == null){
			Route::ErrorPage404();
		}

		// выбираем верхние уровни
		$cats1 = $DB->prepare("SELECT id, name 
							   FROM categories 
							   WHERE id != 1 
							   AND level != 2 
							   AND parent_id != :thisId 
							   ORDER by id");
							   
		$cats1->bindParam(':thisId', $_GET['id']);
		
		$cats1->execute();

		while ($row1 = $cats1->fetch(PDO::FETCH_ASSOC)) {
			$res["parents"][] = $row1;
		}

		// выбираем все шаблоны
		$cats2 = $DB->prepare("SELECT distinct id, name 
							   FROM templates
							   ORDER by id");
		$cats2->execute();

		while ($row2 = $cats2->fetch(PDO::FETCH_ASSOC)) {
			$res["tpls"][] = $row2;
		}

		// рандом класс картинки		
		$res["forForm"] = 'forForm';
		$res["forForm"] .= rand(1, 7);

		return $res;

	}

}