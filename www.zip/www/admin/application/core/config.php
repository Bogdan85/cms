<?php
   global $DB;
   $DB = new PDO("mysql:host=localhost;dbname=main_test", 'root', '');  
   $DB->exec("set names utf8");