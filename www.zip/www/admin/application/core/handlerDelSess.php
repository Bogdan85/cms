<?
session_start();
$_SESSION['login'] = 'closed';
header('Location: http://'.$_SERVER["HTTP_HOST"].'/admin');