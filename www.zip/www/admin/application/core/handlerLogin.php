<?
session_start();
// коннект к БД, возможно потом перенести куда-то?
include_once "config.php";

// переменные	
$login = $_POST['login'];
//$login .= rand(1, 20);
$pass = $_POST['pass'];

$post = $DB->prepare("SELECT pass 
					  FROM users
					  WHERE name = :name");

$post->bindParam(':name', $login);

$post->execute();

while ($row = $post->fetch(PDO::FETCH_ASSOC)) {

	$res = $row["pass"];

}	

$pass .= 'light';
$pass = md5($pass);
$post = null;

if($res == $pass) {

	$_SESSION['login'] = 'opened';

	header('Location: http://'.$_SERVER["HTTP_HOST"].'/admin');

}else{

	$_SESSION['login'] = 'closed';

	header('Location: http://'.$_SERVER["HTTP_HOST"].'/admin');

}