﻿<?
	// коннект к БД, возможно потом перенести куда-то?
	include_once "config.php";
	   
	// обработка аякс функции изменения активности
	if(($_POST['id'] != NULL)and($_POST['value'] != NULL)) {
	
		$id = intval($_POST['id']);
		$value = intval($_POST['value']);
		
		$post = $DB->prepare("UPDATE categories 
							  SET active = :value 
							  WHERE id = :id");
							  
		$post->bindParam(':value', $value);
		$post->bindParam(':id', $id);
											
		$post->execute();
		$post = null;

	}
	
	//  аякс функция удаление категории
	if($_POST['del'] != NULL) {
	   
		$id = intval($_POST['del']);
		
		$post = $DB->prepare("DELETE FROM categories 
							  WHERE id = :id");
							  
		$post->bindParam(':id', $id);
		
		$post->execute();
		$post = null;

	}