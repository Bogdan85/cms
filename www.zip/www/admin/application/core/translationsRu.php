<?
// тут языковые переменные админки

define("rusVar1", "Древо разделов сайта");
define("rusVar2", "Добавить новую страницу");
define("rusVar3", "Выход");
define("rusVar4", "Структура сайта");
define("rusVar5", "Изменение прошло успешно!!!");
define("rusVar6", "Специальные возможности");
define("rusVar7", "Экспорт ХМЛ");
define("rusVar8", "Резервное копирование");
define("rusVar9", "Заказы");
define("rusVar10", "Просмотреть");
define("rusVar11", "Редактировать");
define("rusVar12", "Активность");
define("rusVar13", "Удалить");
define("rusVar14", "Добавление");
define("rusVar15", "Путь в поисковой строке");
define("rusVar16", "Название страницы");
define("rusVar17", "Заголовок страницы");
define("rusVar18", "Кивордс страницы");
define("rusVar19", "Дескрипшн страницы");
define("rusVar20", "H1 страницы");
define("rusVar21", "В хлебной крошке как");
define("rusVar22", "Выводить в меню");
define("rusVar23", "Да");
define("rusVar24", "Нет");
define("rusVar25", "Шаблон");
define("rusVar26", "Без родителя");
define("rusVar27", "Активность");
define("rusVar28", "Редактирование");
define("rusVar29", "Номер материала");
define("rusVar30", "Родитель");
define("rusVar31", "Последняя правка");
define("rusVar32", "Отправить");
define("rusVar33", "SEO CMS");
define("rusVar34", "Логин");
define("rusVar35", "Пароль");
define("rusVar36", "Выполните вход");