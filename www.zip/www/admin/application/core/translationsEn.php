<?
// тут языковые переменные админки

define("rusVar1", "Sitetree");
define("rusVar2", "Add new page");
define("rusVar3", "Exit");
define("rusVar4", "Site structure");
define("rusVar5", "Successful action!!!");
define("rusVar6", "Special abilities");
define("rusVar7", "Export XML");
define("rusVar8", "Backup");
define("rusVar9", "Orders");
define("rusVar10", "View");
define("rusVar11", "Edit");
define("rusVar12", "Activity");
define("rusVar13", "Delete");
define("rusVar14", "Addition");
define("rusVar15", "Url path");
define("rusVar16", "Page name");
define("rusVar17", "Page title");
define("rusVar18", "Page keywords");
define("rusVar19", "Page Description");
define("rusVar20", "Page H1");
define("rusVar21", "Breadcrumb");
define("rusVar22", "Show in menu");
define("rusVar23", "Yes");
define("rusVar24", "No");
define("rusVar25", "Template");
define("rusVar26", "No parent");
define("rusVar27", "Activity");
define("rusVar28", "Edition");
define("rusVar29", "Material number");
define("rusVar30", "Parent");
define("rusVar31", "Last edition");
define("rusVar32", "Send");
define("rusVar33", "SEO CMS");
define("rusVar34", "Login");
define("rusVar35", "Password");
define("rusVar36", "Get inside");