<?
// коннект к БД, возможно потом перенести куда-то?
include_once "config.php";

// апдейтим страницу	
$name = $_POST['name'];
$path = $_POST['path'];
$title = $_POST['title'];
$keywords = $_POST['keywords'];
$description = $_POST['description'];
$h1 = $_POST['h1'];
$text = $_POST['text'];
$for_bread = $_POST['for_bread'];
$template = intval($_POST['template']);
$in_menu = intval($_POST['in_menu']);
$parent_id = intval($_POST['parent_id']);
$active = intval($_POST['active']);		
$time = date('Y-m-d H:i:s');
$level = $parent_id;

// считаем уровень вложенности
if($level == 0) {

	$level = 0;
	
}else{

	// выбираем родителей
	$cats = $DB->prepare("SELECT parent_id 
						  FROM categories 
						  WHERE id = :level");
	
	$cats->bindParam(':level', $level);

	$cats->execute();

	while ($row = $cats->fetch(PDO::FETCH_ASSOC)) {
		$res = $row;
	}

	// выбираем родителей
	if(intval($res["parent_id"]) == 0){
		$level = 1;
	}else{
		$level = 2;
	}
	
	$cats = null;
	
}

$post = $DB->prepare("INSERT into categories
					  VALUES ('', :name, :path, :title, :keywords, :description, :h1, :text, :template, :for_bread, :in_menu, :parent_id, :time, :active, :level)");

$post->bindParam(':active', $active);
$post->bindParam(':name', $name);
$post->bindParam(':path', $path);
$post->bindParam(':title', $title);
$post->bindParam(':keywords', $keywords);
$post->bindParam(':description', $description);
$post->bindParam(':h1', $h1);
$post->bindParam(':text', $text);
$post->bindParam(':template', $template);
$post->bindParam(':for_bread', $for_bread);
$post->bindParam(':in_menu', $in_menu);
$post->bindParam(':parent_id', $parent_id);
$post->bindParam(':time', $time);
$post->bindParam(':level', $level);

if($post->execute()){

	$post = null;
	header('Location: http://'.$_SERVER["HTTP_HOST"].'/admin');

}