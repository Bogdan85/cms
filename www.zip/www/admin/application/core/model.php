<?php
class Model
{	

	public function __construct(){

		include_once "config.php";
	   
	}
	
	// метод выборки данных
	public function get_data()
	{
		// todo
	}
	
}