<!DOCTYPE html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title><?=rusVar1?></title>
		<link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css" />
		<link href="http://fonts.googleapis.com/css?family=Kreon" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="/admin/css/style.css" />
		<script src="/js/jQuery1-7.js" type="text/javascript"></script>
		<script src="/admin/js/adminFuncs.js" type="text/javascript"></script>
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<div id="logo"><?=rusVar33?></div>
				<div id="menu" class="w600">
					<table class="noBord">
						<tr>
							<td><a class="yelCol" href="/admin/add?id=0"><?=rusVar2?></a></td>
							<td>&nbsp;&nbsp;<a class="yelCol" onclick="setCookRu();"><img src="/admin/images/russia.png"></a>&nbsp;/&nbsp;<a class="yelCol" onclick="setCookEn();"><img src="/admin/images/brit.jpg"></a>&nbsp;&nbsp;</td>
							<td><a class="yelCol" href="/admin/application/core/handlerDelSess.php"><?=rusVar3?></a></td>
						</tr>
						<tr>
							<td colspan="3"><h1 class="yelCol"><?=rusVar4?></h1></td>
						</tr>
					</table>
						<div id="hint">
							&nbsp;&nbsp;<?=rusVar5?>
						</div>
				</div>
			</div>
			<div id="page">
				<div id="sidebar">
						<h4><?=rusVar6?></h4>
						<ul>
							<li><a href="#"><?=rusVar7?></a></li>
							<li><a href="#"><?=rusVar8?></a></li>
							<li><a href="#"><?=rusVar9?></a></li>
						</ul>
				</div>
				<div id="content">
				<?

					// вывод древа каталога с возможностью правок
					$count1 = count($data);
					
					for($i=0;$i<$count1;++$i){
					
						// активность раздела для функции
						$toDo = ($data[$i]["active"] > 0 ? 0 : 1);
						
						if($toDo == '0'){
							$imgI = 'notActive.png'; 
						}elseif($toDo == '1'){
							$imgI = 'active.png'; 
						}
						
						// если главная - убираем слеш
						if($data[$i]["path"] == '/') {
							$data[$i]["path"] = '';
						}
						
						// если главная - нельзя удалять						
						if($data[$i]["id"] == 1) {
							$notShow = 'display:none;';
						}else{
							$notShow = '';
						}

						echo '<p><b>'.$data[$i]["name"].'&nbsp;&nbsp;&nbsp;<a href="/'.$data[$i]["path"].'"><img alt="'.rusVar10.'" title="'.rusVar10.'" src="/admin/images/view.png" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;<a href="/admin/edit?id='.$data[$i]["id"].'"><img alt="'.rusVar11.'" title="'.rusVar11.'" src="/admin/images/edit.png" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;<span id="toChange'.$data[$i]["id"].'"><a href="#" onclick="change_but('.$data[$i]["id"].', '.$toDo.');"><img alt="'.rusVar12.'" title="'.rusVar12.'" src="/admin/images/'.$imgI.'" align="absmiddle"></a></span>&nbsp;&nbsp;&nbsp;<a style='.$notShow.' href="#" onclick="del_cat('.$data[$i]["id"].');"><img alt="'.rusVar13.'" title="'.rusVar13.'" src="/admin/images/delete.png" align="absmiddle"></a></b></p>';
						if(isset($data[$i]["subs"])){

							$count2 = count($data[$i]["subs"]);
						
							for($ii=0;$ii<$count2;++$ii){
							
								// активность раздела для функции							
								$toDo = ($data[$i]["subs"][$ii]["active"] > 0 ? 0 : 1);
						
								if($toDo == '0'){
									$imgI = 'notActive.png'; 
								}elseif($toDo == '1'){
									$imgI = 'active.png'; 
								}
							
								echo '<p class="mrgLft30"><b>'.$data[$i]["subs"][$ii]["name"].'&nbsp;&nbsp;&nbsp;<a href="/'.$data[$i]["path"].'/'.$data[$i]["subs"][$ii]["path"].'"><img alt="'.rusVar10.'" title="'.rusVar10.'" src="/admin/images/view.png" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;<a href="/admin/edit?id='.$data[$i]["subs"][$ii]["id"].'"><img alt="'.rusVar11.'" title="'.rusVar11.'" src="/admin/images/edit.png" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;<span id="toChange'.$data[$i]["subs"][$ii]["id"].'"><a href="#" onclick="change_but('.$data[$i]["subs"][$ii]["id"].', '.$toDo.');"><img alt="'.rusVar12.'" title="'.rusVar12.'" src="/admin/images/'.$imgI.'" align="absmiddle"></a></span>&nbsp;&nbsp;&nbsp;<a href="#" onclick="del_cat('.$data[$i]["subs"][$ii]["id"].');"><img alt="'.rusVar13.'" title="'.rusVar13.'" src="/admin/images/delete.png" align="absmiddle"></a></b></p>';
								
								$count3 = count($data[$i]["subs"][$ii]["subs"]);
								
								for($aa=0;$aa<$count3;++$aa){
									
									// активность раздела для функции							
									$toDo = ($data[$i]["subs"][$ii]["subs"][$aa] > 0 ? 0 : 1);

									if($toDo == '0'){
										$imgI = 'notActive.png'; 
									}elseif($toDo == '1'){
										$imgI = 'active.png'; 
									}

									echo '<p class="mrgLft60"><b>'.$data[$i]["subs"][$ii]["subs"][$aa]["name"].'&nbsp;&nbsp;&nbsp;<a href="/'.$data[$i]["path"].'/'.$data[$i]["subs"][$ii]["path"].'/'.$data[$i]["subs"][$ii]["subs"][$aa]["path"].'"><img alt="'.rusVar10.'" title="'.rusVar10.'" src="/admin/images/view.png" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;<a href="/admin/edit?id='.$data[$i]["subs"][$ii]["subs"][$aa]["id"].'"><img alt="'.rusVar11.'" title="'.rusVar11.'" src="/admin/images/edit.png" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;<span id="toChange'.$data[$i]["subs"][$ii]["subs"][$aa]["id"].'"><a href="#" onclick="change_but('.$data[$i]["subs"][$ii]["subs"][$aa]["id"].', '.$toDo.');"><img alt="'.rusVar12.'" title="'.rusVar12.'" src="/admin/images/'.$imgI.'" align="absmiddle"></a></span>&nbsp;&nbsp;&nbsp;<a href="#" onclick="del_cat('.$data[$i]["subs"][$ii]["subs"][$aa]["id"].');"><img alt="'.rusVar13.'" title="'.rusVar13.'" src="/admin/images/delete.png" align="absmiddle"></a></b></p>';

								}
							}
						}
					}
				?>
					<br class="clearfix" />
				</div>
				<br class="clearfix" />
			</div>
		</div>
	</body>
</html>