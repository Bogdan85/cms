﻿<!DOCTYPE html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title><?=rusVar14?></title>
		<link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css" />
		<link href="http://fonts.googleapis.com/css?family=Kreon" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="/admin/css/style.css" />
		<script src="/js/jQuery1-7.js" type="text/javascript"></script>
		<script src="/admin/js/adminFuncs.js" type="text/javascript"></script>
		<script type="text/javascript" src="/admin/tinymce/js/tinymce/tiny_mce.js"></script>
		<script type="text/javascript">
		tinyMCE.init({    
				
				language : "en",
				// General options
				mode : "specific_textareas",
				editor_selector : "mceEditor",
				theme : "advanced",
				plugins : "spellchecker,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",

				// Theme options
				theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect",
				theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
				theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
				theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,spellchecker,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,blockquote,pagebreak,|,insertfile,insertimage",
				theme_advanced_toolbar_location : "top",
				theme_advanced_toolbar_align : "left",
				theme_advanced_statusbar_location : "bottom",
				theme_advanced_resizing : true,

				// Skin options
				skin : "o2k7",
				skin_variant : "silver"        

		});
		</script>
	</head>
	<body>
		<div class="<?=$data["forForm"]?>">
			<form method="post" action="/admin/application/core/handlerAdd.php">
				<table class="maintable">
				<tr><td valign="top"><?=rusVar15?> <input required type="text" name="path" value=""></td></tr>
				<tr><td valign="top"><?=rusVar16?> <input required type="text" name="name" value=""></td></tr>
				<tr><td valign="top"><?=rusVar17?> <textarea name="title"></textarea></td></tr>
				<tr><td valign="top"><?=rusVar18?> <textarea name="keywords"></textarea></td></tr>
				<tr><td valign="top"><?=rusVar19?> <textarea name="description"></textarea></td></tr>
				<tr><td valign="top"><?=rusVar20?> <textarea name="h1"></textarea></td></tr>
				<tr><td valign="top"><?=rusVar21?> <input type="text" name="for_bread" value=""></td></tr>
				<tr><td valign="top"><textarea name="text" class="mceEditor"></textarea></td></tr>
				<tr><td valign="top"><?=rusVar22?>
						<select name="in_menu">
							<option value="1"><?=rusVar23?></option>
							<option selected value="0"><?=rusVar24?></option>';								
						</select>
					</td>
				</tr>
				<?
					echo '<tr><td valign="top">'.rusVar25.' <select required name="template">';
					
						$count1 = count($data["tpls"]);
					
						for($i=0;$i<$count1;++$i){
						
							echo '<option value="'.$data["tpls"][$i]["id"].'">'.$data["tpls"][$i]["name"].'</option>';
			
						}	
						
					echo '</select></td></tr>';
				?>
				<?
					echo '<tr><td valign="top">'.rusVar30.' <select required name="parent_id">';
							
							echo '<option selected value="0">'.rusVar26.'</option>';
							
						$count2 = count($data["parents"]);
					
						for($i=0;$i<$count2;++$i){
						
							if(intval($data["parents"][$i]["id"]) != 1) {

								echo '<option value="'.$data["parents"][$i]["id"].'">'.$data["parents"][$i]["name"].'</option>';
							
							}
			
						}	
						
					echo '</select></td></tr>';
				?>
				<tr>
					<td valign="top"><?=rusVar27?>
						<select name="active">
							<option value="1"><?=rusVar24?></option>
							<option value="0"><?=rusVar23?></option>
						</select>
					</td>
				</tr>
				<tr align="center"><td><input class="redCol" type="submit" value="<?=rusVar32?>"></td></tr>
				</table>
			</form>
		</div>
	</body>
</html>