﻿<!DOCTYPE html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title><?=rusVar28?></title>
		<link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css" />
		<link href="http://fonts.googleapis.com/css?family=Kreon" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="/admin/css/style.css" />
		<script src="/js/jQuery1-7.js" type="text/javascript"></script>
		<script src="/admin/js/adminFuncs.js" type="text/javascript"></script>
		<script type="text/javascript" src="/admin/tinymce/js/tinymce/tiny_mce.js"></script>
		<script type="text/javascript">
		tinyMCE.init({    
				
				language : "en",
				// General options
				mode : "specific_textareas",
				editor_selector : "mceEditor",
				theme : "advanced",
				plugins : "spellchecker,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",

				// Theme options
				theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect",
				theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
				theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
				theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,spellchecker,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,blockquote,pagebreak,|,insertfile,insertimage",
				theme_advanced_toolbar_location : "top",
				theme_advanced_toolbar_align : "left",
				theme_advanced_statusbar_location : "bottom",
				theme_advanced_resizing : true,

				// Skin options
				skin : "o2k7",
				skin_variant : "silver"        

		});
		</script>
	</head>
	<body>
		<div class="<?=$data["forForm"]?>">
			<form method="post" action="/admin/application/core/handlerEdit.php">
				<table class="maintable">
				<?php
					$idGet = $_GET['id'];
					
					foreach($data["main"] as $key => $value) {
					
						switch ($key) {
						
							case 'id':
								echo '<tr><td class="redCol">'.rusVar29.'   <b>'.$value.'</b></td></tr>';
								break;
							case 'path':
								echo '<tr><td valign="top">'.rusVar15.' <input type="text" name="'.$key.'" value="'.$value.'"></td></tr>';
								break;
							case 'name':
								echo '<tr><td valign="top">'.rusVar16.' <input type="text" name="'.$key.'" value="'.$value.'"></td></tr>';
								break;
							case 'title':
								echo '<tr><td valign="top">'.rusVar17.' <textarea name="'.$key.'">'.$value.'</textarea></td></tr>';
								break;
							case 'keywords':
								echo '<tr><td valign="top">'.rusVar18.' <textarea name="'.$key.'">'.$value.'</textarea></td></tr>';
								break;
							case 'description':
								echo '<tr><td valign="top">'.rusVar19.' <textarea name="'.$key.'">'.$value.'</textarea></td></tr>';
								break;
							case 'h1':
								echo '<tr><td valign="top">'.rusVar20.' <textarea name="'.$key.'">'.$value.'</textarea></td></tr>';
								break;
							case 'for_bread':
								echo '<tr><td valign="top">'.rusVar21.' <input type="text" name="'.$key.'" value="'.$value.'"></td></tr>';
								break;
							case 'text':
								echo '<tr><td valign="top"><textarea name="'.$key.'" class="mceEditor">'.$value.'</textarea></td></tr>';
								break;
							case 'in_menu':
								echo '<tr><td valign="top">'.rusVar22.' <select name="'.$key.'">';
								
									if(intval($value) == 1){
										echo '<option selected value="1">'.rusVar23.'</option>';									
									}else{
										echo '<option value="1">'.rusVar23.'</option>';									
									}
									
									if(intval($value) == 0){
										echo '<option selected value="0">'.rusVar24.'</option>';								
									}else{
										echo '<option value="0">'.rusVar24.'</option>';								
									}
									
								echo '</select></td></tr>';
								break;
							case 'template':
								echo '<tr><td valign="top">'.rusVar25.' <select name="'.$key.'">';
								
									$count1 = count($data["tpls"]);
								
									for($i=0;$i<$count1;++$i){

										if(intval($value) == intval($data["tpls"][$i]["id"])){
											echo '<option selected value="'.$data["tpls"][$i]["id"].'">'.$data["tpls"][$i]["name"].'</option>';										
										}else{
											echo '<option value="'.$data["tpls"][$i]["id"].'">'.$data["tpls"][$i]["name"].'</option>';										
										}
						
									}	
									
								echo '</select></td></tr>';
								break;
							case 'parent_id':
								echo '<tr><td valign="top">'.rusVar30.' <select name="'.$key.'">';
															
									echo '<option value="0">'.rusVar26.'</option>';
									
									$count2 = count($data["parents"]);
								
									for($i=0;$i<$count2;++$i){
									
										if((intval($data["parents"][$i]["id"]) != 1)and(intval($_GET["id"]) != intval($data["parents"][$i]["id"]))) {

											if(intval($value) == intval($data["parents"][$i]["id"])){
												echo '<option selected value="'.$data["parents"][$i]["id"].'">'.$data["parents"][$i]["name"].'</option>';										
											}else{
												echo '<option value="'.$data["parents"][$i]["id"].'">'.$data["parents"][$i]["name"].'</option>';										
											}
										
										}
						
									}	
									
								echo '</select></td></tr>';
								break;
							case 'active':
								echo '<tr><td valign="top">'.rusVar27.' <select name="'.$key.'">';
									
									if(intval($value) == 1){
										echo '<option selected value="1">'.rusVar24.'</option>';									
									}else{
										echo '<option value="1">'.rusVar24.'</option>';									
									}
									
									if(intval($value) == 0){
										echo '<option selected value="0">'.rusVar23.'</option>';								
									}else{
										echo '<option value="0">'.rusVar23.'</option>';								
									}
									
								echo '</select></td></tr>';
								break;
							case 'time':
								echo '<tr><td valign="top">'.rusVar31.' <b>'.$value.'</b></td></tr>';
								break;
							default:
								echo '<tr><td valign="top"<textarea name="'.$key.'">'.$value.'</textarea></td></tr>';
								break;
							
						}
					
					}
				?>
				<input type="hidden" name="get" value="<?=$idGet?>">
				<tr align="center"><td><input class="redCol" type="submit" value="<?=rusVar32?>"></td></tr>
				</table>
			</form>
		</div>
	</body>
</html>