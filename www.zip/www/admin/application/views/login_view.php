<!DOCTYPE html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<title><?=rusVar36?></title>
		<link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css" />
		<link href="http://fonts.googleapis.com/css?family=Kreon" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="/admin/css/style.css" />
		<script src="/js/jQuery1-7.js" type="text/javascript"></script>
		<script src="/admin/js/adminFuncs.js" type="text/javascript"></script>
	</head>
	<body>
			<form method="post" action="/admin/application/core/handlerLogin.php">
				<table class="logForm">
					<tr>
						<td colspan="2" align="center"><b><?=rusVar33?></b></td>
					</tr>
					<tr>
						<td><b><?=rusVar34?></b></td>
						<td><input name="login" required type="text" size="20" value=""></td>
					</tr>
					<tr>
						<td><b><?=rusVar35?></b></td>
						<td><input name="pass" required type="text" size="20" value=""></td>
					</tr>
					<tr>
						<td colspan="2" align="center"><input class="redCol" type="submit" value="<?=rusVar32?>"></td>
					</tr>
				</table>
			</form>
		</table>
	</body>
</html>