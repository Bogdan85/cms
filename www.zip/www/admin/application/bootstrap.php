<?php
// подключаем файлы ядра
session_start();
include_once 'core/model.php';
include_once 'core/view.php';
include_once 'core/controller.php';
include_once 'core/custom.php';

switch($_COOKIE["language"]){

	case 'en':
	include_once 'core/translationsEn.php';	
	
	case 'ru':
	include_once 'core/translationsRu.php';	
	
	default:	
	include_once 'core/translationsRu.php';
	
}

/*
Здесь обычно подключаются дополнительные модули, реализующие различный функционал:
	> аутентификацию
	> кеширование
	> работу с формами
	> абстракции для доступа к данным
	> ORM
	> Unit тестирование
	> Benchmarking
	> Работу с изображениями
	> Backup
	> и др.
*/
include_once 'core/route.php';
Route::start(); // запускаем маршрутизатор